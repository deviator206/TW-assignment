var gApp = {};

gApp.AppConstant ={

	INIT_STATE:0,
	PAGE_NAME:["landingPage","searchPage"],
	INVALID_NAME :"Invalid SRC/DEST",
	INVALID_START_DATE:"Invalid Start Date",
	INVALID_END_DATE:"Invalid End Date",
	INVALID_PASSENGER_COUNT:"Invalid Passenger Count",
	INVALID_START_RANGE:" Invalid Start Range",
	INVALID_END_RANGE:" Invalid End Range",
	SELECT_END_DATE:"Select Return Date",
	SELECT_START_DATE:"Select Start Date",
	SEARCH_RESULT_METADATA:{
					"route":'Pune>Delhi'
	},
	SEARCH_RESULT :[
			{
				"cost":"24",
				"flightName":"SP",
				"flightRoute":"SH>PNQ>DEL",
				"flightDepartTime":"12:00:12",
				"flightArriveTime":"12:99",
				"isReturn":false,
				"returnFlightName":"ASAS",
				"returnFlightRoute":"PNG>as>as",
				"returnFlightDepartTime":"12/23/12",
				"returnFlightArriveTime":"12:90"
				
				
			},
			{
				"cost":"1234",
				"flightName":"SP1",
				"flightRoute":"SH>PNQ>DEL1",
				"flightDepartTime":"12:00:121111",
				"flightArriveTime":"12:991111",
				"isReturn":true,
				"returnFlightName":"ASA1S",
				"returnFlightRoute":"PNG>as>a1s",
				"returnFlightDepartTime":"12/23/12",
				"returnFlightArriveTime":"12:90"
				
				
			}
	
	
	]	
}




