

gApp.LandingPage = function()
{
	this.setUp();
}

gApp.LandingPage.prototype = {

	setUp:function()
	{
		//set the initial page 
	}

}
